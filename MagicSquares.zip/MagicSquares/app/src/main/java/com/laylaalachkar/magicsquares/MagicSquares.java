package com.laylaalachkar.magicsquares;

import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.preference.PreferenceManager;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.DragEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;


public class MagicSquares extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_magic_squares);

        setTitle("Magic Squares");

        findViewById(R.id.draggable1).setOnTouchListener(new MyTouchListener());
        findViewById(R.id.draggable2).setOnTouchListener(new MyTouchListener());
        findViewById(R.id.draggable3).setOnTouchListener(new MyTouchListener());
        findViewById(R.id.draggable4).setOnTouchListener(new MyTouchListener());
        findViewById(R.id.draggable5).setOnTouchListener(new MyTouchListener());
        findViewById(R.id.draggable6).setOnTouchListener(new MyTouchListener());
        findViewById(R.id.draggable7).setOnTouchListener(new MyTouchListener());
        findViewById(R.id.draggable8).setOnTouchListener(new MyTouchListener());
        findViewById(R.id.draggable9).setOnTouchListener(new MyTouchListener());

        findViewById(R.id.droppable1).setOnDragListener(new MyDragListener());
        findViewById(R.id.droppable2).setOnDragListener(new MyDragListener());
        findViewById(R.id.droppable3).setOnDragListener(new MyDragListener());
        findViewById(R.id.droppable4).setOnDragListener(new MyDragListener());
        findViewById(R.id.droppable5).setOnDragListener(new MyDragListener());
        findViewById(R.id.droppable6).setOnDragListener(new MyDragListener());
        findViewById(R.id.droppable7).setOnDragListener(new MyDragListener());
        findViewById(R.id.droppable8).setOnDragListener(new MyDragListener());
        findViewById(R.id.droppable9).setOnDragListener(new MyDragListener());

    }

    private TextView dragged = null;
    private final class MyTouchListener implements View.OnTouchListener{
        public boolean onTouch(View view, MotionEvent motionEvent)
        {
            if(motionEvent.getAction() == MotionEvent.ACTION_DOWN)
            {
                ClipData data = ClipData.newPlainText("", "");
                View.DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(view);
                view.startDrag(data, shadowBuilder, view, 0);
                //view.setVisibility(View.INVISIBLE);
                return true;
            }
            else
            {
                return false;
            }
        }
    }

    private final class MyDragListener implements View.OnDragListener
    {
        Drawable enterShape = getResources().getDrawable(R.drawable.box_highlight);
        Drawable normalShape = getResources().getDrawable(R.drawable.box);

        public boolean onDrag(View v, DragEvent event)
        {
            switch(event.getAction()) {
                case DragEvent.ACTION_DRAG_STARTED:
                    // Do nothing
                    break;
                case DragEvent.ACTION_DRAG_ENTERED:
                    v.setBackgroundDrawable(enterShape);
                    break;
                case DragEvent.ACTION_DRAG_EXITED:
                    v.setBackgroundDrawable(normalShape);
                    break;
                case DragEvent.ACTION_DROP:
                    // Dropped, reassign view to viewGroup
                    View view = (View) event.getLocalState();
                    TextView dropTarget = (TextView) v;
                    TextView dropped = (TextView)view;
                    if(dropTarget.getText().toString().equals(""))
                    {
                        view.setVisibility(View.INVISIBLE);
                        dropTarget.setText(dropped.getText().toString());
                        checkIfFilled();
                    }
                    break;
                case DragEvent.ACTION_DRAG_ENDED:
                    v.setBackgroundDrawable(normalShape);
                default:
                    break;
            }
            return true;
        }
    }
    private void checkIfFilled()
    {
        TextView drop1 = (TextView)findViewById(R.id.droppable1);
        TextView drop2 = (TextView)findViewById(R.id.droppable2);
        TextView drop3 = (TextView)findViewById(R.id.droppable3);
        TextView drop4 = (TextView)findViewById(R.id.droppable4);
        TextView drop5 = (TextView)findViewById(R.id.droppable5);
        TextView drop6 = (TextView)findViewById(R.id.droppable6);
        TextView drop7 = (TextView)findViewById(R.id.droppable7);
        TextView drop8 = (TextView)findViewById(R.id.droppable8);
        TextView drop9 = (TextView)findViewById(R.id.droppable9);

        if(!drop1.getText().toString().equals("") && !drop2.getText().toString().equals("") &&
                !drop3.getText().toString().equals("") && !drop4.getText().toString().equals("") &&
                !drop5.getText().toString().equals("") && !drop6.getText().toString().equals("") &&
                !drop7.getText().toString().equals("") && !drop8.getText().toString().equals("") &&
                !drop9.getText().toString().equals(""))
        {
            Intent intent = new Intent(this, GameOver.class);
            intent.putExtra("num1", Integer.parseInt(drop1.getText().toString()));
            intent.putExtra("num2", Integer.parseInt(drop2.getText().toString()));
            intent.putExtra("num3", Integer.parseInt(drop3.getText().toString()));
            intent.putExtra("num4", Integer.parseInt(drop4.getText().toString()));
            intent.putExtra("num5", Integer.parseInt(drop5.getText().toString()));
            intent.putExtra("num6", Integer.parseInt(drop6.getText().toString()));
            intent.putExtra("num7", Integer.parseInt(drop7.getText().toString()));
            intent.putExtra("num8", Integer.parseInt(drop8.getText().toString()));
            intent.putExtra("num9", Integer.parseInt(drop9.getText().toString()));

            startActivity(intent);
        }

    }
    private boolean resumedBefore = false;

    public void onResume() {
        super.onResume();
        TextView drag1 = (TextView) findViewById(R.id.draggable1);
        TextView drag2 = (TextView) findViewById(R.id.draggable2);
        TextView drag3 = (TextView) findViewById(R.id.draggable3);
        TextView drag4 = (TextView) findViewById(R.id.draggable4);
        TextView drag5 = (TextView) findViewById(R.id.draggable5);
        TextView drag6 = (TextView) findViewById(R.id.draggable6);
        TextView drag7 = (TextView) findViewById(R.id.draggable7);
        TextView drag8 = (TextView) findViewById(R.id.draggable8);
        TextView drag9 = (TextView) findViewById(R.id.draggable9);
        if (!resumedBefore) {
            resumedBefore = true;
        } else {
            SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
            String gameId = prefs.getString(getString(R.string.game_pref), "");
            if (gameId.equals("1")) {
                drag1.setText("2");
                drag2.setText("7");
                drag3.setText("6");
                drag4.setText("1");
                drag5.setText("4");
                drag6.setText("3");
                drag7.setText("8");
                drag8.setText("9");
                drag9.setText("5");
                resetGame();
                drag1.setTextSize(50); drag2.setTextSize(50); drag3.setTextSize(50); drag4.setTextSize(50);
                drag5.setTextSize(50); drag6.setTextSize(50); drag7.setTextSize(50); drag8.setTextSize(50);
                drag9.setTextSize(50);
            } else if (gameId.equals("2")) {
                drag1.setText("4");
                drag2.setText("6");
                drag3.setText("9");
                drag4.setText("1");
                drag5.setText("2");
                drag6.setText("8");
                drag7.setText("3");
                drag8.setText("7");
                drag9.setText("5");
                resetGame();
                drag1.setTextSize(50); drag2.setTextSize(50); drag3.setTextSize(50); drag4.setTextSize(50);
                drag5.setTextSize(50); drag6.setTextSize(50); drag7.setTextSize(50); drag8.setTextSize(50);
                drag9.setTextSize(50);
            } else if (gameId.equals("3")) {
                drag1.setText("23");
                drag2.setText("28");
                drag3.setText("21");
                drag4.setText("24");
                drag5.setText("20");
                drag6.setText("26");
                drag7.setText("22");
                drag8.setText("25");
                drag9.setText("27");
                resetGame();
                drag1.setTextSize(24); drag2.setTextSize(24); drag3.setTextSize(24); drag4.setTextSize(24);
                drag5.setTextSize(24); drag6.setTextSize(24); drag7.setTextSize(24); drag8.setTextSize(24);
                drag9.setTextSize(24);
            } else if (gameId.equals("4")) {
                drag1.setText("3");
                drag2.setText("5");
                drag3.setText("2");
                drag4.setText("7");
                drag5.setText("4");
                drag6.setText("6");
                drag7.setText("9");
                drag8.setText("8");
                drag9.setText("1");
                resetGame();
                drag1.setTextSize(50); drag2.setTextSize(50); drag3.setTextSize(50); drag4.setTextSize(50);
                drag5.setTextSize(50); drag6.setTextSize(50); drag7.setTextSize(50); drag8.setTextSize(50);
                drag9.setTextSize(50);
            } else if (gameId.equals("5")) {
                drag1.setText("8");
                drag2.setText("5");
                drag3.setText("2");
                drag4.setText("1");
                drag5.setText("7");
                drag6.setText("6");
                drag7.setText("3");
                drag8.setText("9");
                drag9.setText("4");
                resetGame();
                drag1.setTextSize(50); drag2.setTextSize(50); drag3.setTextSize(50); drag4.setTextSize(50);
                drag5.setTextSize(50); drag6.setTextSize(50); drag7.setTextSize(50); drag8.setTextSize(50);
                drag9.setTextSize(50);
            } else if (gameId.equals("6")) {
                drag1.setText("17");
                drag2.setText("113");
                drag3.setText("89");
                drag4.setText("59");
                drag5.setText("29");
                drag6.setText("71");
                drag7.setText("5");
                drag8.setText("47");
                drag9.setText("101");
                resetGame();
                drag1.setTextSize(23); drag2.setTextSize(23); drag3.setTextSize(23); drag4.setTextSize(23);
                drag5.setTextSize(23); drag6.setTextSize(23); drag7.setTextSize(23); drag8.setTextSize(23);
                drag9.setTextSize(23);
            } else if (gameId.equals("7")) {
                drag1.setText("7");
                drag2.setText("2");
                drag3.setText("0");
                drag4.setText("3");
                drag5.setText("8");
                drag6.setText("4");
                drag7.setText("1");
                drag8.setText("6");
                drag9.setText("5");
                resetGame();
                drag1.setTextSize(50); drag2.setTextSize(50); drag3.setTextSize(50); drag4.setTextSize(50);
                drag5.setTextSize(50); drag6.setTextSize(50); drag7.setTextSize(50); drag8.setTextSize(50);
                drag9.setTextSize(50);
            } else if (gameId.equals("8")) {
                drag1.setText("1");
                drag2.setText("1");
                drag3.setText("1");
                drag4.setText("2");
                drag5.setText("2");
                drag6.setText("2");
                drag7.setText("0");
                drag8.setText("0");
                drag9.setText("0");
                resetGame();
                drag1.setTextSize(50); drag2.setTextSize(50); drag3.setTextSize(50); drag4.setTextSize(50);
                drag5.setTextSize(50); drag6.setTextSize(50); drag7.setTextSize(50); drag8.setTextSize(50);
                drag9.setTextSize(50);
            } else if (gameId.equals("9")) {
                drag1.setText("7");
                drag2.setText("2");
                drag3.setText("3");
                drag4.setText("8");
                drag5.setText("4");
                drag6.setText("5");
                drag7.setText("0");
                drag8.setText("6");
                drag9.setText("1");
                resetGame();
                drag1.setTextSize(50); drag2.setTextSize(50); drag3.setTextSize(50); drag4.setTextSize(50);
                drag5.setTextSize(50); drag6.setTextSize(50); drag7.setTextSize(50); drag8.setTextSize(50);
                drag9.setTextSize(50);
            } else if (gameId.equals("10")) {
                drag1.setText("1");
                drag2.setText("2");
                drag3.setText("3");
                drag4.setText("4");
                drag5.setText("5");
                drag6.setText("6");
                drag7.setText("7");
                drag8.setText("8");
                drag9.setText("9");
                resetGame();
                drag1.setTextSize(50); drag2.setTextSize(50); drag3.setTextSize(50); drag4.setTextSize(50);
                drag5.setTextSize(50); drag6.setTextSize(50); drag7.setTextSize(50); drag8.setTextSize(50);
                drag9.setTextSize(50);
            } else // default game
            {
                drag1.setText("2");
                drag2.setText("7");
                drag3.setText("6");
                drag4.setText("1");
                drag5.setText("4");
                drag6.setText("3");
                drag7.setText("8");
                drag8.setText("9");
                drag9.setText("5");
                resetGame();
                drag1.setTextSize(50); drag2.setTextSize(50); drag3.setTextSize(50); drag4.setTextSize(50);
                drag5.setTextSize(50); drag6.setTextSize(50); drag7.setTextSize(50); drag8.setTextSize(50);
                drag9.setTextSize(50);
            }
        }

    }
    private void resetGame()
    {
       // drag items
        TextView drag1 = (TextView) findViewById(R.id.draggable1);
        TextView drag2 = (TextView) findViewById(R.id.draggable2);
        TextView drag3 = (TextView) findViewById(R.id.draggable3);
        TextView drag4 = (TextView) findViewById(R.id.draggable4);
        TextView drag5 = (TextView) findViewById(R.id.draggable5);
        TextView drag6 = (TextView) findViewById(R.id.draggable6);
        TextView drag7 = (TextView) findViewById(R.id.draggable7);
        TextView drag8 = (TextView) findViewById(R.id.draggable8);
        TextView drag9 = (TextView) findViewById(R.id.draggable9);

        // drop items
        TextView drop1 = (TextView)findViewById(R.id.droppable1);
        TextView drop2 = (TextView)findViewById(R.id.droppable2);
        TextView drop3 = (TextView)findViewById(R.id.droppable3);
        TextView drop4 = (TextView)findViewById(R.id.droppable4);
        TextView drop5 = (TextView)findViewById(R.id.droppable5);
        TextView drop6 = (TextView)findViewById(R.id.droppable6);
        TextView drop7 = (TextView)findViewById(R.id.droppable7);
        TextView drop8 = (TextView)findViewById(R.id.droppable8);
        TextView drop9 = (TextView)findViewById(R.id.droppable9);

        // turn on visibility
        drag1.setVisibility(View.VISIBLE);
        drag2.setVisibility(View.VISIBLE);
        drag3.setVisibility(View.VISIBLE);
        drag4.setVisibility(View.VISIBLE);
        drag5.setVisibility(View.VISIBLE);
        drag6.setVisibility(View.VISIBLE);
        drag7.setVisibility(View.VISIBLE);
        drag8.setVisibility(View.VISIBLE);
        drag9.setVisibility(View.VISIBLE);

        // set game board back to empty
        drop1.setText("");
        drop2.setText("");
        drop3.setText("");
        drop4.setText("");
        drop5.setText("");
        drop6.setText("");
        drop7.setText("");
        drop8.setText("");
        drop9.setText("");
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_magic_squares, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.new_game)
        {
            //Pick a new game
            Intent intent = new Intent(this, preferences.class);
            startActivity(intent);
            return true;
        }
        if(id == R.id.reset_game)
        {
            resetGame();
            return true;
        }
        if(id == R.id.help)
        {
            Intent intent = new Intent(this, HelpMessage.class);
            startActivity(intent);
            return true; 
        }


        return super.onOptionsItemSelected(item);
    }
}
