package com.laylaalachkar.magicsquares;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;


public class GameOver extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_over);
        setTitle("Play Again");

        boolean won = determineIfGameWasWon();
        TextView message = (TextView)findViewById(R.id.message);
        ImageView image = (ImageView)findViewById(R.id.imageView);
        if(won)
        {
            // winners window
            message.setText("You Won!");
            message.setTextSize(50);
            image.setImageResource(R.drawable.win_elephant);

        }
        else
        {
            // loser window
            message.setText("You Lost");
            message.setTextSize(50);
            image.setImageResource(R.drawable.lose_elephant);
        }
    }


    private boolean determineIfGameWasWon()
    {
        Intent intent = getIntent();
        int num1 = intent.getIntExtra("num1", 0);
        int num2 = intent.getIntExtra("num2", 0);
        int num3 = intent.getIntExtra("num3", 0);
        int num4 = intent.getIntExtra("num4", 0);
        int num5 = intent.getIntExtra("num5", 0);
        int num6 = intent.getIntExtra("num6", 0);
        int num7 = intent.getIntExtra("num7", 0);
        int num8 = intent.getIntExtra("num8", 0);
        int num9 = intent.getIntExtra("num9", 0);

        // convert to numbers
        TextView message = (TextView)findViewById(R.id.message);
        int row1 = num1 + num2 + num3;
        int row2 = num4 + num5 + num6;
        int row3 = num7 + num8 + num9;
        int col1 = num1 + num4 + num7;
        int col2 = num2 + num5 + num8;
        int col3 = num3 + num6 + num9;
        int diag1 = num1 + num5 + num9;
        int diag2 = num3 + num5 + num7;

        if(row1 != row2 || row1 != row3 || row1 != col1 || row1 != col2 || row1 != col3
                || row1 != diag1 || row1 != diag2)
        {
            return false;
        }
        return true;
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_game_over, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement

        if (id == R.id.new_game)
        {
            //Pick a new game
            Intent intent = new Intent(this, preferences.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
